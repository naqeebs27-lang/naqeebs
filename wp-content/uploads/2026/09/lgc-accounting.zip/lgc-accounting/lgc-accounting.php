<?php
/**
 * Plugin Name: LGC Accounting System
 * Description: Free WordPress accounting dashboard converted from the supplied Excel workbook. Includes chart of accounts, double-entry journal, ledger, trial balance, income statement, balance sheet, petty cash, payroll, vouchers, CSV import/export and a seeded copy of the workbook data.
 * Version: 1.0.0
 * Author: OpenAI
 * License: GPL-2.0-or-later
 */
if (!defined('ABSPATH')) exit;

class LGC_Accounting {
    private static $instance;
    private $t = [];
    public static function instance(){ return self::$instance ?: self::$instance = new self; }
    private function __construct(){
        global $wpdb;
        $p=$wpdb->prefix;
        $this->t=[
            'accounts'=>$p.'lgc_accounts','journal'=>$p.'lgc_journal',
            'petty'=>$p.'lgc_petty_cash','payroll'=>$p.'lgc_payroll','vouchers'=>$p.'lgc_vouchers'
        ];
        register_activation_hook(__FILE__, [$this,'activate']);
        add_action('admin_menu',[$this,'menu']);
        add_action('admin_enqueue_scripts',[$this,'assets']);
        add_action('admin_post_lgc_save_account',[$this,'save_account']);
        add_action('admin_post_lgc_save_journal',[$this,'save_journal']);
        add_action('admin_post_lgc_save_petty',[$this,'save_petty']);
        add_action('admin_post_lgc_save_payroll',[$this,'save_payroll']);
        add_action('admin_post_lgc_save_voucher',[$this,'save_voucher']);
        add_action('admin_post_lgc_export',[$this,'export_csv']);
        add_action('admin_post_lgc_import',[$this,'import_csv']);
        add_shortcode('lgc_accounting',[$this,'shortcode']);
    }
    private function table($name){return $this->t[$name];}
    public function activate(){
        global $wpdb;
        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        $c=$wpdb->get_charset_collate();
        $sql=[];
        $sql[]="CREATE TABLE {$this->table('accounts')} (
            id bigint unsigned NOT NULL AUTO_INCREMENT, account_id varchar(30) NOT NULL, name varchar(190) NOT NULL,
            category varchar(100) NOT NULL, type varchar(60) NOT NULL, created_at datetime NOT NULL,
            PRIMARY KEY(id), UNIQUE KEY account_id(account_id), KEY name(name)) $c;";
        $sql[]="CREATE TABLE {$this->table('journal')} (
            id bigint unsigned NOT NULL AUTO_INCREMENT, txn_date date NOT NULL, r_no varchar(50), v_no varchar(50),
            account_id varchar(30) NOT NULL, description text, debit decimal(18,2) NOT NULL DEFAULT 0,
            credit decimal(18,2) NOT NULL DEFAULT 0, created_by bigint unsigned, created_at datetime NOT NULL,
            PRIMARY KEY(id), KEY txn_date(txn_date), KEY account_id(account_id), KEY r_no(r_no)) $c;";
        $sql[]="CREATE TABLE {$this->table('petty')} (
            id bigint unsigned NOT NULL AUTO_INCREMENT, txn_date date NOT NULL, r_no varchar(50), description text,
            cash_received decimal(18,2) NOT NULL DEFAULT 0, amount_ih decimal(18,2) NOT NULL DEFAULT 0,
            cash_paid decimal(18,2) NOT NULL DEFAULT 0, account varchar(190), created_at datetime NOT NULL,
            PRIMARY KEY(id), KEY txn_date(txn_date)) $c;";
        $sql[]="CREATE TABLE {$this->table('payroll')} (
            id bigint unsigned NOT NULL AUTO_INCREMENT, employee_id varchar(30), employee_name varchar(190) NOT NULL,
            designation varchar(190), salary_month date, due_date date, monthly_salary decimal(18,2) DEFAULT 0,
            allowance decimal(18,2) DEFAULT 0, total_salary decimal(18,2) DEFAULT 0, advance_paid decimal(18,2) DEFAULT 0,
            paid decimal(18,2) DEFAULT 0, balance decimal(18,2) DEFAULT 0, paid_on varchar(190), created_at datetime NOT NULL,
            PRIMARY KEY(id), KEY salary_month(salary_month)) $c;";
        $sql[]="CREATE TABLE {$this->table('vouchers')} (
            id bigint unsigned NOT NULL AUTO_INCREMENT, voucher_no varchar(50), voucher_date date NOT NULL,
            voucher_type varchar(50) DEFAULT 'Petty Cash', payee varchar(190), description text,
            amount decimal(18,2) DEFAULT 0, account varchar(190), created_at datetime NOT NULL,
            PRIMARY KEY(id), KEY voucher_date(voucher_date)) $c;";
        foreach($sql as $q) dbDelta($q);
        if (!get_option('lgc_seeded')) { $this->seed(); update_option('lgc_seeded',1); }
    }
    private function seed(){
        $file=plugin_dir_path(__FILE__).'data.json';
        if(!file_exists($file)) return;
        $data=json_decode(file_get_contents($file),true);
        if(!$data) return;
        global $wpdb;
        $now=current_time('mysql');
        foreach(($data['accounts']??[]) as $r){
            if(count($r)>=4) $wpdb->insert($this->table('accounts'),['account_id'=>sanitize_text_field($r[1]),'name'=>sanitize_text_field($r[0]),'category'=>sanitize_text_field($r[2]),'type'=>sanitize_text_field($r[3]),'created_at'=>$now]);
        }
        foreach(($data['journal']??[]) as $r){
            if(count($r)>=8 && $r[0] && $r[7]){
                $wpdb->insert($this->table('journal'),['txn_date'=>sanitize_text_field($r[0]),'r_no'=>sanitize_text_field($r[1]),'account_id'=>sanitize_text_field($r[2]),'v_no'=>sanitize_text_field($r[3]),'description'=>sanitize_textarea_field($r[4]),'debit'=>(float)$r[5],'credit'=>(float)$r[6],'created_at'=>$now]);
            }
        }
        foreach(($data['petty_cash']??[]) as $r){
            if(count($r)>=7 && $r[0]) $wpdb->insert($this->table('petty'),['txn_date'=>sanitize_text_field($r[0]),'r_no'=>sanitize_text_field($r[1]),'description'=>sanitize_textarea_field($r[2]),'cash_received'=>(float)$r[3],'amount_ih'=>(float)$r[4],'cash_paid'=>(float)$r[5],'account'=>sanitize_text_field($r[6]),'created_at'=>$now]);
        }
        foreach(($data['payroll']??[]) as $r){
            if(count($r)>=12 && $r[1]) $wpdb->insert($this->table('payroll'),['employee_id'=>sanitize_text_field($r[0]),'employee_name'=>sanitize_text_field($r[1]),'designation'=>sanitize_text_field($r[2]),'salary_month'=>$r[3]?:null,'due_date'=>$r[4]?:null,'monthly_salary'=>(float)$r[5],'allowance'=>(float)$r[6],'total_salary'=>(float)$r[7],'advance_paid'=>(float)$r[8],'paid'=>(float)$r[9],'balance'=>(float)$r[10],'paid_on'=>sanitize_text_field($r[11]),'created_at'=>$now]);
        }
    }
    public function menu(){
        add_menu_page('LGC Accounting','LGC Accounting','manage_options','lgc-accounting',[$this,'page_dashboard'],'dashicons-chart-area',26);
        $pages=[
            ['Dashboard','lgc-accounting','page_dashboard'],
            ['Journal','lgc-journal','page_journal'],
            ['Chart of Accounts','lgc-coa','page_coa'],
            ['Ledger','lgc-ledger','page_ledger'],
            ['Trial Balance','lgc-trial','page_trial'],
            ['Income Statement','lgc-income','page_income'],
            ['Balance Sheet','lgc-balance','page_balance'],
            ['Petty Cash','lgc-petty','page_petty'],
            ['Payroll','lgc-payroll','page_payroll'],
            ['Vouchers','lgc-vouchers','page_vouchers'],
            ['Import / Export','lgc-io','page_io']
        ];
        foreach($pages as $p) add_submenu_page('lgc-accounting',$p[0],$p[0],'manage_options',$p[1],[$this,$p[2]]);
    }
    public function assets($hook){
        if(strpos($hook,'lgc-')===false && strpos($hook,'lgc_accounting')===false) return;
        wp_enqueue_style('lgc-admin',plugins_url('assets/admin.css',__FILE__),[], '1.0.0');
    }
    private function head($title){
        echo '<div class="wrap lgc-wrap"><div class="lgc-top"><div><h1>'.esc_html($title).'</h1><p class="description">LGC Accounting System</p></div><a class="button" href="'.esc_url(admin_url('admin.php?page=lgc-accounting')).'">← Dashboard</a></div>';
        if(isset($_GET['lgc_msg'])) echo '<div class="notice notice-success is-dismissible"><p>'.esc_html(wp_unslash($_GET['lgc_msg'])).'</p></div>';
    }
    private function foot(){ echo '</div>'; }
    private function money($n){return number_format((float)$n,2);}
    private function filters(){
        $from=isset($_GET['from'])?sanitize_text_field(wp_unslash($_GET['from'])):date('Y-01-01');
        $to=isset($_GET['to'])?sanitize_text_field(wp_unslash($_GET['to'])):date('Y-m-d');
        return [$from,$to];
    }
    private function cards($items){
        echo '<div class="lgc-cards">';
        foreach($items as $x) echo '<div class="lgc-card"><div class="lgc-card-label">'.esc_html($x[0]).'</div><div class="lgc-card-value">'.esc_html($x[1]).'</div></div>';
        echo '</div>';
    }
    public function page_dashboard(){
        global $wpdb; $j=$this->table('journal'); [$from,$to]=$this->filters();
        $debit=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(debit),0) FROM $j WHERE txn_date BETWEEN %s AND %s",$from,$to));
        $credit=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(credit),0) FROM $j WHERE txn_date BETWEEN %s AND %s",$from,$to));
        $accounts=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$this->table('accounts')}");
        $entries=(int)$wpdb->get_var("SELECT COUNT(*) FROM $j");
        $this->head('Accounting Dashboard');
        echo '<form class="lgc-filter" method="get"><input type="hidden" name="page" value="lgc-accounting"><label>From <input type="date" name="from" value="'.esc_attr($from).'"></label><label>To <input type="date" name="to" value="'.esc_attr($to).'"></label><button class="button button-primary">Apply</button></form>';
        $this->cards([['Total Debit',$this->money($debit)],['Total Credit',$this->money($credit)],['Difference',$this->money($debit-$credit)],['Accounts',$accounts],['Journal Lines',$entries]]);
        echo '<div class="lgc-command-grid">';
        $cmd=['lgc-journal'=>'Journal Entry','lgc-coa'=>'Chart of Accounts','lgc-ledger'=>'General Ledger','lgc-trial'=>'Trial Balance','lgc-income'=>'Income Statement','lgc-balance'=>'Balance Sheet','lgc-petty'=>'Petty Cash','lgc-payroll'=>'Payroll','lgc-vouchers'=>'Vouchers','lgc-io'=>'Import / Export'];
        foreach($cmd as $slug=>$label) echo '<a class="lgc-command" href="'.esc_url(admin_url('admin.php?page='.$slug)).'">'.esc_html($label).'<span>Open →</span></a>';
        echo '</div><div class="lgc-note"><strong>Double-entry check:</strong> '.($debit===$credit?'Balanced for selected period.':'Difference detected — review journal lines for the selected period.').'</div>';
        $this->foot();
    }
    public function page_coa(){
        global $wpdb; $rows=$wpdb->get_results("SELECT * FROM {$this->table('accounts')} ORDER BY account_id",ARRAY_A);
        $this->head('Chart of Accounts');
        echo '<div class="lgc-panel"><h2>Add Account</h2><form class="lgc-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'">'.wp_nonce_field('lgc_account','_wpnonce',true,false).'<input type="hidden" name="action" value="lgc_save_account"><input name="account_id" placeholder="A100" required><input name="name" placeholder="Account name" required><input name="category" placeholder="Category" required><select name="type"><option>Assets</option><option>Liability</option><option>Owner Equity</option><option>Income</option><option>Expense</option></select><button class="button button-primary">Save Account</button></form></div>';
        echo '<table class="widefat striped"><thead><tr><th>ID</th><th>Account</th><th>Category</th><th>Type</th></tr></thead><tbody>';
        foreach($rows as $r) echo '<tr><td>'.esc_html($r['account_id']).'</td><td>'.esc_html($r['name']).'</td><td>'.esc_html($r['category']).'</td><td>'.esc_html($r['type']).'</td></tr>';
        echo '</tbody></table>'; $this->foot();
    }
    public function save_account(){
        if(!current_user_can('manage_options')||!check_admin_referer('lgc_account')) wp_die('Unauthorized');
        global $wpdb; $wpdb->insert($this->table('accounts'),['account_id'=>sanitize_text_field($_POST['account_id']),'name'=>sanitize_text_field($_POST['name']),'category'=>sanitize_text_field($_POST['category']),'type'=>sanitize_text_field($_POST['type']),'created_at'=>current_time('mysql')]);
        wp_safe_redirect(admin_url('admin.php?page=lgc-coa&lgc_msg='.rawurlencode('Account saved.'))); exit;
    }
    private function account_options(){
        global $wpdb; $rows=$wpdb->get_results("SELECT account_id,name FROM {$this->table('accounts')} ORDER BY name");
        $o=''; foreach($rows as $r) $o.='<option value="'.esc_attr($r->account_id).'">'.esc_html($r->name).' ('.esc_html($r->account_id).')</option>'; return $o;
    }
    public function page_journal(){
        global $wpdb; $rows=$wpdb->get_results("SELECT j.*,a.name FROM {$this->table('journal')} j LEFT JOIN {$this->table('accounts')} a ON a.account_id=j.account_id ORDER BY j.txn_date DESC,j.id DESC LIMIT 200",ARRAY_A);
        $this->head('Journal Entries');
        echo '<div class="lgc-panel"><h2>Post Journal Line</h2><p class="description">Enter one debit or credit line. For a transaction, post at least two lines with equal total debits and credits.</p><form class="lgc-form lgc-grid" method="post" action="'.esc_url(admin_url('admin-post.php')).'">'.wp_nonce_field('lgc_journal','_wpnonce',true,false).'<input type="hidden" name="action" value="lgc_save_journal"><input type="date" name="txn_date" value="'.esc_attr(date('Y-m-d')).'" required><input name="r_no" placeholder="R-No"><input name="v_no" placeholder="V-No"><select name="account_id" required><option value="">Select account</option>'.$this->account_options().'</select><input class="wide" name="description" placeholder="Description" required><input type="number" step="0.01" min="0" name="debit" placeholder="Debit"><input type="number" step="0.01" min="0" name="credit" placeholder="Credit"><button class="button button-primary">Post Line</button></form></div>';
        echo '<table class="widefat striped"><thead><tr><th>Date</th><th>R-No</th><th>V-No</th><th>Account</th><th>Description</th><th>Debit</th><th>Credit</th></tr></thead><tbody>';
        foreach($rows as $r) echo '<tr><td>'.esc_html($r['txn_date']).'</td><td>'.esc_html($r['r_no']).'</td><td>'.esc_html($r['v_no']).'</td><td>'.esc_html($r['name']?:$r['account_id']).'</td><td>'.esc_html($r['description']).'</td><td>'.esc_html($this->money($r['debit'])).'</td><td>'.esc_html($this->money($r['credit'])).'</td></tr>';
        echo '</tbody></table>'; $this->foot();
    }
    public function save_journal(){
        if(!current_user_can('manage_options')||!check_admin_referer('lgc_journal')) wp_die('Unauthorized');
        global $wpdb; $d=max(0,(float)($_POST['debit']??0)); $c=max(0,(float)($_POST['credit']??0));
        if(($d>0 && $c>0)||($d==0&&$c==0)) wp_die('Enter either a debit or a credit amount.');
        $wpdb->insert($this->table('journal'),['txn_date'=>sanitize_text_field($_POST['txn_date']),'r_no'=>sanitize_text_field($_POST['r_no']),'v_no'=>sanitize_text_field($_POST['v_no']),'account_id'=>sanitize_text_field($_POST['account_id']),'description'=>sanitize_textarea_field($_POST['description']),'debit'=>$d,'credit'=>$c,'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')]);
        wp_safe_redirect(admin_url('admin.php?page=lgc-journal&lgc_msg='.rawurlencode('Journal line posted.'))); exit;
    }
    public function page_ledger(){
        global $wpdb; [$from,$to]=$this->filters(); $acct=isset($_GET['account'])?sanitize_text_field(wp_unslash($_GET['account'])):'';
        $where=$wpdb->prepare("WHERE j.txn_date BETWEEN %s AND %s",$from,$to); if($acct) $where.=$wpdb->prepare(" AND j.account_id=%s",$acct);
        $rows=$wpdb->get_results("SELECT j.*,a.name FROM {$this->table('journal')} j LEFT JOIN {$this->table('accounts')} a ON a.account_id=j.account_id $where ORDER BY j.txn_date,j.id",ARRAY_A);
        $td=$wpdb->get_var("SELECT COALESCE(SUM(debit),0) FROM {$this->table('journal')} j $where"); $tc=$wpdb->get_var("SELECT COALESCE(SUM(credit),0) FROM {$this->table('journal')} j $where");
        $this->head('General Ledger');
        echo '<form class="lgc-filter" method="get"><input type="hidden" name="page" value="lgc-ledger"><label>From <input type="date" name="from" value="'.esc_attr($from).'"></label><label>To <input type="date" name="to" value="'.esc_attr($to).'"></label><label>Account <select name="account"><option value="">All</option>'.$this->account_options_selected($acct).'</select></label><button class="button button-primary">Filter</button></form>';
        echo '<div class="lgc-note">Debit: <strong>'.$this->money($td).'</strong> &nbsp; Credit: <strong>'.$this->money($tc).'</strong> &nbsp; Difference: <strong>'.$this->money($td-$tc).'</strong></div>';
        echo '<table class="widefat striped"><thead><tr><th>Date</th><th>R-No</th><th>Account</th><th>Description</th><th>Debit</th><th>Credit</th><th>Running Balance</th></tr></thead><tbody>';
        $bal=0; foreach($rows as $r){$bal+=(float)$r['debit']-(float)$r['credit']; echo '<tr><td>'.esc_html($r['txn_date']).'</td><td>'.esc_html($r['r_no']).'</td><td>'.esc_html($r['name']?:$r['account_id']).'</td><td>'.esc_html($r['description']).'</td><td>'.esc_html($this->money($r['debit'])).'</td><td>'.esc_html($this->money($r['credit'])).'</td><td>'.esc_html($this->money($bal)).'</td></tr>';}
        echo '</tbody></table>'; $this->foot();
    }
    private function account_options_selected($sel){
        global $wpdb; $rows=$wpdb->get_results("SELECT account_id,name FROM {$this->table('accounts')} ORDER BY name"); $o='';
        foreach($rows as $r) $o.='<option value="'.esc_attr($r->account_id).'" '.selected($sel,$r->account_id,false).'>'.esc_html($r->name).' ('.esc_html($r->account_id).')</option>'; return $o;
    }
    private function report_rows($from,$to){
        global $wpdb; return $wpdb->get_results($wpdb->prepare("SELECT a.account_id,a.name,a.category,a.type,COALESCE(SUM(j.debit),0) debit,COALESCE(SUM(j.credit),0) credit,COALESCE(SUM(j.debit-j.credit),0) balance FROM {$this->table('accounts')} a LEFT JOIN {$this->table('journal')} j ON j.account_id=a.account_id AND j.txn_date BETWEEN %s AND %s GROUP BY a.id ORDER BY a.account_id",$from,$to),ARRAY_A);
    }
    public function page_trial(){
        [$from,$to]=$this->filters(); $rows=$this->report_rows($from,$to); $this->head('Trial Balance');
        $this->filter_report($from,$to,'lgc-trial'); echo '<table class="widefat striped"><thead><tr><th>Account ID</th><th>Type</th><th>Account</th><th>Category</th><th>Debit</th><th>Credit</th><th>Balance</th></tr></thead><tbody>';
        $d=$c=0; foreach($rows as $r){$d+=(float)$r['debit'];$c+=(float)$r['credit'];echo '<tr><td>'.esc_html($r['account_id']).'</td><td>'.esc_html($r['type']).'</td><td>'.esc_html($r['name']).'</td><td>'.esc_html($r['category']).'</td><td>'.esc_html($this->money($r['debit'])).'</td><td>'.esc_html($this->money($r['credit'])).'</td><td>'.esc_html($this->money($r['balance'])).'</td></tr>';}
        echo '</tbody><tfoot><tr><th colspan="4">Totals</th><th>'.$this->money($d).'</th><th>'.$this->money($c).'</th><th>'.$this->money($d-$c).'</th></tr></tfoot></table>'; $this->foot();
    }
    private function filter_report($from,$to,$slug){echo '<form class="lgc-filter" method="get"><input type="hidden" name="page" value="'.esc_attr($slug).'"><label>From <input type="date" name="from" value="'.esc_attr($from).'"></label><label>To <input type="date" name="to" value="'.esc_attr($to).'"></label><button class="button button-primary">Apply</button></form>';}
    public function page_income(){
        [$from,$to]=$this->filters(); $rows=$this->report_rows($from,$to); $this->head('Income Statement'); $this->filter_report($from,$to,'lgc-income');
        $income=$expense=0; echo '<table class="widefat striped"><thead><tr><th>Account</th><th>Type</th><th>Debit</th><th>Credit</th><th>Net</th></tr></thead><tbody>';
        foreach($rows as $r) if(in_array($r['type'],['Income','Expense'],true)){ $net=(float)$r['credit']-(float)$r['debit']; if($r['type']==='Income')$income+=$net;else $expense+=-$net; echo '<tr><td>'.esc_html($r['name']).'</td><td>'.esc_html($r['type']).'</td><td>'.$this->money($r['debit']).'</td><td>'.$this->money($r['credit']).'</td><td>'.$this->money($net).'</td></tr>'; }
        echo '</tbody><tfoot><tr><th colspan="4">Net Income</th><th>'.$this->money($income-$expense).'</th></tr></tfoot></table>'; $this->foot();
    }
    public function page_balance(){
        [$from,$to]=$this->filters(); $rows=$this->report_rows($from,$to); $this->head('Balance Sheet'); $this->filter_report($from,$to,'lgc-balance');
        echo '<table class="widefat striped"><thead><tr><th>Category</th><th>Account ID</th><th>Account</th><th>Debit</th><th>Credit</th><th>Balance</th></tr></thead><tbody>';
        foreach($rows as $r) if(in_array($r['type'],['Assets','Liability','Owner Equity'],true)) echo '<tr><td>'.esc_html($r['category']).'</td><td>'.esc_html($r['account_id']).'</td><td>'.esc_html($r['name']).'</td><td>'.$this->money($r['debit']).'</td><td>'.$this->money($r['credit']).'</td><td>'.$this->money($r['balance']).'</td></tr>';
        echo '</tbody></table>'; $this->foot();
    }
    public function page_petty(){
        global $wpdb; $rows=$wpdb->get_results("SELECT * FROM {$this->table('petty')} ORDER BY txn_date DESC,id DESC LIMIT 300",ARRAY_A);
        $this->head('Petty Cash');
        echo '<div class="lgc-panel"><h2>Petty Cash Entry</h2><form class="lgc-form lgc-grid" method="post" action="'.esc_url(admin_url('admin-post.php')).'">'.wp_nonce_field('lgc_petty','_wpnonce',true,false).'<input type="hidden" name="action" value="lgc_save_petty"><input type="date" name="txn_date" value="'.esc_attr(date('Y-m-d')).'" required><input name="r_no" placeholder="R-No"><input class="wide" name="description" placeholder="Description" required><input type="number" step="0.01" min="0" name="cash_received" placeholder="Cash Received"><input type="number" step="0.01" min="0" name="amount_ih" placeholder="Amount IH"><input type="number" step="0.01" min="0" name="cash_paid" placeholder="Cash Paid"><input name="account" placeholder="Account"><button class="button button-primary">Save Entry</button></form></div>';
        echo '<table class="widefat striped"><thead><tr><th>Date</th><th>Description</th><th>Received</th><th>Amount IH</th><th>Paid</th><th>Running Balance</th><th>Account</th></tr></thead><tbody>';
        $bal=0; $rev=array_reverse($rows); foreach($rev as $r){$bal+=(float)$r['cash_received']+(float)$r['amount_ih']-(float)$r['cash_paid'];} $bal=0;
        foreach($rows as $r){$bal+=(float)$r['cash_received']+(float)$r['amount_ih']-(float)$r['cash_paid'];echo '<tr><td>'.esc_html($r['txn_date']).'</td><td>'.esc_html($r['description']).'</td><td>'.$this->money($r['cash_received']).'</td><td>'.$this->money($r['amount_ih']).'</td><td>'.$this->money($r['cash_paid']).'</td><td>'.$this->money($bal).'</td><td>'.esc_html($r['account']).'</td></tr>';}
        echo '</tbody></table>'; $this->foot();
    }
    public function save_petty(){
        if(!current_user_can('manage_options')||!check_admin_referer('lgc_petty')) wp_die('Unauthorized'); global $wpdb;
        $wpdb->insert($this->table('petty'),['txn_date'=>sanitize_text_field($_POST['txn_date']),'r_no'=>sanitize_text_field($_POST['r_no']),'description'=>sanitize_textarea_field($_POST['description']),'cash_received'=>(float)($_POST['cash_received']??0),'amount_ih'=>(float)($_POST['amount_ih']??0),'cash_paid'=>(float)($_POST['cash_paid']??0),'account'=>sanitize_text_field($_POST['account']),'created_at'=>current_time('mysql')]);
        wp_safe_redirect(admin_url('admin.php?page=lgc-petty&lgc_msg='.rawurlencode('Petty cash entry saved.'))); exit;
    }
    public function page_payroll(){
        global $wpdb; $rows=$wpdb->get_results("SELECT * FROM {$this->table('payroll')} ORDER BY salary_month DESC,id DESC LIMIT 300",ARRAY_A); $this->head('Payroll');
        echo '<div class="lgc-panel"><h2>Add Payroll Record</h2><form class="lgc-form lgc-grid" method="post" action="'.esc_url(admin_url('admin-post.php')).'">'.wp_nonce_field('lgc_payroll','_wpnonce',true,false).'<input type="hidden" name="action" value="lgc_save_payroll"><input name="employee_id" placeholder="Employee ID"><input name="employee_name" placeholder="Employee name" required><input name="designation" placeholder="Designation"><input type="date" name="salary_month"><input type="date" name="due_date"><input type="number" step="0.01" name="monthly_salary" placeholder="Monthly Salary"><input type="number" step="0.01" name="allowance" placeholder="Allowance"><input type="number" step="0.01" name="advance_paid" placeholder="Advance Paid"><input type="number" step="0.01" name="paid" placeholder="Paid"><input name="paid_on" placeholder="Paid on / note"><button class="button button-primary">Save Payroll</button></form></div>';
        echo '<table class="widefat striped"><thead><tr><th>ID</th><th>Employee</th><th>Designation</th><th>Salary Month</th><th>Total</th><th>Advance</th><th>Paid</th><th>Balance</th><th>Paid On</th></tr></thead><tbody>';
        foreach($rows as $r) echo '<tr><td>'.esc_html($r['employee_id']).'</td><td>'.esc_html($r['employee_name']).'</td><td>'.esc_html($r['designation']).'</td><td>'.esc_html($r['salary_month']).'</td><td>'.$this->money($r['total_salary']).'</td><td>'.$this->money($r['advance_paid']).'</td><td>'.$this->money($r['paid']).'</td><td>'.$this->money($r['balance']).'</td><td>'.esc_html($r['paid_on']).'</td></tr>';
        echo '</tbody></table>'; $this->foot();
    }
    public function save_payroll(){
        if(!current_user_can('manage_options')||!check_admin_referer('lgc_payroll')) wp_die('Unauthorized'); global $wpdb;
        $salary=(float)($_POST['monthly_salary']??0);$allow=(float)($_POST['allowance']??0);$adv=(float)($_POST['advance_paid']??0);$paid=(float)($_POST['paid']??0);
        $wpdb->insert($this->table('payroll'),['employee_id'=>sanitize_text_field($_POST['employee_id']),'employee_name'=>sanitize_text_field($_POST['employee_name']),'designation'=>sanitize_text_field($_POST['designation']),'salary_month'=>sanitize_text_field($_POST['salary_month']),'due_date'=>sanitize_text_field($_POST['due_date']),'monthly_salary'=>$salary,'allowance'=>$allow,'total_salary'=>$salary+$allow,'advance_paid'=>$adv,'paid'=>$paid,'balance'=>$salary+$allow-$adv-$paid,'paid_on'=>sanitize_text_field($_POST['paid_on']),'created_at'=>current_time('mysql')]);
        wp_safe_redirect(admin_url('admin.php?page=lgc-payroll&lgc_msg='.rawurlencode('Payroll record saved.'))); exit;
    }
    public function page_vouchers(){
        global $wpdb; $rows=$wpdb->get_results("SELECT * FROM {$this->table('vouchers')} ORDER BY voucher_date DESC,id DESC LIMIT 200",ARRAY_A); $this->head('Petty Cash Vouchers');
        echo '<div class="lgc-panel"><h2>Create Voucher</h2><form class="lgc-form lgc-grid" method="post" action="'.esc_url(admin_url('admin-post.php')).'">'.wp_nonce_field('lgc_voucher','_wpnonce',true,false).'<input type="hidden" name="action" value="lgc_save_voucher"><input name="voucher_no" placeholder="Voucher No"><input type="date" name="voucher_date" value="'.esc_attr(date('Y-m-d')).'" required><select name="voucher_type"><option>Petty Cash</option><option>Payment</option><option>Receipt</option><option>Journal</option></select><input name="payee" placeholder="Payee"><input name="account" placeholder="Account"><input type="number" step="0.01" name="amount" placeholder="Amount"><input class="wide" name="description" placeholder="Description"><button class="button button-primary">Create Voucher</button></form></div>';
        echo '<table class="widefat striped"><thead><tr><th>Voucher</th><th>Date</th><th>Type</th><th>Payee</th><th>Account</th><th>Description</th><th>Amount</th></tr></thead><tbody>';
        foreach($rows as $r) echo '<tr><td>'.esc_html($r['voucher_no']).'</td><td>'.esc_html($r['voucher_date']).'</td><td>'.esc_html($r['voucher_type']).'</td><td>'.esc_html($r['payee']).'</td><td>'.esc_html($r['account']).'</td><td>'.esc_html($r['description']).'</td><td>'.$this->money($r['amount']).'</td></tr>';
        echo '</tbody></table>'; $this->foot();
    }
    public function save_voucher(){
        if(!current_user_can('manage_options')||!check_admin_referer('lgc_voucher')) wp_die('Unauthorized'); global $wpdb;
        $wpdb->insert($this->table('vouchers'),['voucher_no'=>sanitize_text_field($_POST['voucher_no']),'voucher_date'=>sanitize_text_field($_POST['voucher_date']),'voucher_type'=>sanitize_text_field($_POST['voucher_type']),'payee'=>sanitize_text_field($_POST['payee']),'account'=>sanitize_text_field($_POST['account']),'description'=>sanitize_textarea_field($_POST['description']),'amount'=>(float)($_POST['amount']??0),'created_at'=>current_time('mysql')]);
        wp_safe_redirect(admin_url('admin.php?page=lgc-vouchers&lgc_msg='.rawurlencode('Voucher created.'))); exit;
    }
    public function page_io(){
        $this->head('Import / Export');
        echo '<div class="lgc-io-grid"><div class="lgc-panel"><h2>Export CSV</h2><p>Download live WordPress data for backup or Excel editing.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'.wp_nonce_field('lgc_io','_wpnonce',true,false).'<input type="hidden" name="action" value="lgc_export"><select name="dataset"><option value="accounts">Chart of Accounts</option><option value="journal">Journal</option><option value="petty">Petty Cash</option><option value="payroll">Payroll</option><option value="vouchers">Vouchers</option></select> <button class="button button-primary">Export CSV</button></form></div>';
        echo '<div class="lgc-panel"><h2>Import CSV</h2><p>Use the exported CSV format. Import adds records; it does not delete existing data.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'" enctype="multipart/form-data">'.wp_nonce_field('lgc_io','_wpnonce',true,false).'<input type="hidden" name="action" value="lgc_import"><select name="dataset"><option value="accounts">Chart of Accounts</option><option value="journal">Journal</option><option value="petty">Petty Cash</option><option value="payroll">Payroll</option><option value="vouchers">Vouchers</option></select><input type="file" name="csv" accept=".csv,text/csv" required> <button class="button button-primary">Import CSV</button></form></div></div>';
        echo '<div class="lgc-note"><strong>Excel conversion:</strong> the supplied workbook data was bundled into this plugin and is seeded automatically on first activation. New WordPress records are stored in the database, not in Excel.</div>'; $this->foot();
    }
    public function export_csv(){
        if(!current_user_can('manage_options')||!check_admin_referer('lgc_io')) wp_die('Unauthorized'); global $wpdb;
        $ds=sanitize_key($_POST['dataset']); if(!isset($this->t[$ds])) wp_die('Invalid dataset'); $rows=$wpdb->get_results("SELECT * FROM {$this->t[$ds]}",ARRAY_A);
        nocache_headers(); header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename=lgc-'.$ds.'-'.date('Y-m-d').'.csv');
        $out=fopen('php://output','w'); if($rows) {fputcsv($out,array_keys($rows[0])); foreach($rows as $r) fputcsv($out,$r);} fclose($out); exit;
    }
    public function import_csv(){
        if(!current_user_can('manage_options')||!check_admin_referer('lgc_io')) wp_die('Unauthorized');
        if(empty($_FILES['csv']['tmp_name'])||!is_uploaded_file($_FILES['csv']['tmp_name'])) wp_die('CSV upload failed.');
        $ds=sanitize_key($_POST['dataset']); global $wpdb; $map=[
            'accounts'=>['account_id','name','category','type'],
            'journal'=>['txn_date','r_no','v_no','account_id','description','debit','credit'],
            'petty'=>['txn_date','r_no','description','cash_received','amount_ih','cash_paid','account'],
            'payroll'=>['employee_id','employee_name','designation','salary_month','due_date','monthly_salary','allowance','total_salary','advance_paid','paid','balance','paid_on'],
            'vouchers'=>['voucher_no','voucher_date','voucher_type','payee','description','amount','account']
        ]; if(!isset($map[$ds])) wp_die('Invalid dataset'); $fh=fopen($_FILES['csv']['tmp_name'],'r');$header=fgetcsv($fh); if(!$header) wp_die('Empty CSV.');
        $count=0; while(($row=fgetcsv($fh))!==false){$assoc=[];foreach($header as $i=>$h){if(in_array($h,$map[$ds],true))$assoc[$h]=$row[$i]??'';} if($assoc){$assoc=$this->sanitize_import($ds,$assoc);$assoc['created_at']=current_time('mysql');$wpdb->insert($this->t[$ds],$assoc);$count++;}} fclose($fh);
        wp_safe_redirect(admin_url('admin.php?page=lgc-io&lgc_msg='.rawurlencode("$count records imported."))); exit;
    }
    private function sanitize_import($ds,$a){
        foreach($a as $k=>$v){if(strpos($k,'date')!==false||$k==='salary_month'||$k==='due_date')$a[$k]=sanitize_text_field($v);elseif(in_array($k,['debit','credit','cash_received','amount_ih','cash_paid','monthly_salary','allowance','total_salary','advance_paid','paid','balance','amount'],true))$a[$k]=(float)$v;else $a[$k]=sanitize_textarea_field($v);}
        return $a;
    }
    public function shortcode(){
        if(!current_user_can('manage_options')) return '<p>Accounting access is restricted to authorized users.</p>';
        ob_start(); echo '<div class="lgc-front"><h2>LGC Accounting Dashboard</h2><p>Open the WordPress admin menu <strong>LGC Accounting</strong> to manage accounts, journals and reports.</p><a class="button" href="'.esc_url(admin_url('admin.php?page=lgc-accounting')).'">Open Accounting</a></div>'; return ob_get_clean();
    }
}
LGC_Accounting::instance();
