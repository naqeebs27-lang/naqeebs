# LGC Accounting System – Free WordPress Plugin

## What this is
A free, self-contained WordPress accounting plugin converted from the supplied Excel workbook **WP Dashboard Accounting System 01-09-2026.xlsx**.

The plugin uses the WordPress database and does not require Excel, VBA, PivotTables, or third-party PHP libraries.

## Included
- Accounting dashboard with date filters and double-entry balance check
- Chart of Accounts
- Journal / double-entry ledger lines
- General Ledger with account/date filtering and running balance
- Trial Balance
- Income Statement
- Balance Sheet
- Petty Cash ledger
- Payroll register with total, advance, paid and balance
- Petty Cash / Payment / Receipt / Journal vouchers
- CSV import/export for all major modules
- Seeded data extracted from the supplied workbook on first activation
- WordPress admin permissions and nonce protection
- Responsive admin interface
- Shortcode: `[lgc_accounting]`

## Installation
1. In WordPress go to **Plugins → Add New → Upload Plugin**.
2. Upload `lgc-accounting.zip`.
3. Activate it.
4. Open **LGC Accounting** in the WordPress admin menu.

## Important
The workbook contains historical/formula-driven data. This plugin converts the operational data into database records and recalculates reports from those records. Excel-specific PivotTables and formulas are intentionally replaced with live SQL reports.

The seeded data is inserted only on the first activation. If you deactivate/reactivate after data has already been seeded, it will not duplicate the seed data.

## Requirements
- WordPress 6.x or later
- PHP 7.4+ (PHP 8.x recommended)
- MySQL/MariaDB supported by WordPress

## License
GPL-2.0-or-later.
